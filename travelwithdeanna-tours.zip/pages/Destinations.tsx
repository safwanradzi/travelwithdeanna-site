import React, { useState } from 'react';
import { Layout } from '../components/Layout';
import { Button, Section, SectionHeader, FadeIn, ScaleOnHover } from '../components/UIComponents';
import { DESTINATIONS } from '../constants';

const Destinations = () => {
  const [filterRegion, setFilterRegion] = useState('All');
  const [filterStyle, setFilterStyle] = useState('All');

  const regions = ['All', 'Europe', 'Middle East', 'Asia', 'Americas', 'Islands'];
  const styles = ['All', 'City', 'Nature', 'Historical', 'Winter'];

  const filteredDestinations = DESTINATIONS.filter(dest => {
    const regionMatch = filterRegion === 'All' || dest.region === filterRegion;
    const styleMatch = filterStyle === 'All' || dest.style === filterStyle;
    return regionMatch && styleMatch;
  });

  return (
    <Layout>
      <div className="pt-32 pb-12 bg-brand-grey/30">
        <Section className="!py-0">
          <SectionHeader 
            title="Explore Our Destinations" 
            subtitle="Choose from curated travel experiences across Europe, Asia, Middle East, Americas, and beautiful islands worldwide."
            center
          />
          
          {/* Filters */}
          <div className="flex flex-col md:flex-row justify-center gap-6 mb-12">
            <div className="space-y-2 text-center md:text-left">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-wider block">Region</label>
              <div className="flex flex-wrap justify-center md:justify-start gap-2">
                {regions.map(r => (
                  <button
                    key={r}
                    onClick={() => setFilterRegion(r)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                      filterRegion === r 
                        ? 'bg-brand-navy text-white shadow-lg' 
                        : 'bg-white text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2 text-center md:text-left">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-wider block">Travel Style</label>
              <div className="flex flex-wrap justify-center md:justify-start gap-2">
                {styles.map(s => (
                  <button
                    key={s}
                    onClick={() => setFilterStyle(s)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                      filterStyle === s 
                        ? 'bg-brand-gold text-white shadow-lg' 
                        : 'bg-white text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </Section>
      </div>

      <Section>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredDestinations.length > 0 ? (
            filteredDestinations.map((dest) => (
              <FadeIn key={dest.id}>
                <ScaleOnHover>
                  <div className="bg-white rounded-2xl overflow-hidden shadow-soft h-full flex flex-col group border border-gray-100">
                    <div className="relative h-64 overflow-hidden">
                      <img 
                        src={dest.image} 
                        alt={dest.title} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      {/* Badge removed as per request to remove duration concepts */}
                      <div className="absolute bottom-4 left-4 bg-brand-gold text-white text-xs font-bold px-3 py-1 rounded-full shadow-sm">
                        {dest.region}
                      </div>
                    </div>
                    <div className="p-6 flex flex-col flex-grow">
                      <h3 className="text-2xl font-heading font-bold text-brand-navy mb-3">{dest.title}</h3>
                      <p className="text-gray-500 text-sm mb-6 flex-grow line-clamp-3">{dest.description}</p>
                      <Button to={`/package/${dest.id}`} variant="outline" fullWidth className="group-hover:bg-brand-navy group-hover:text-white group-hover:border-brand-navy">
                        View Details
                      </Button>
                    </div>
                  </div>
                </ScaleOnHover>
              </FadeIn>
            ))
          ) : (
             <div className="col-span-full text-center py-20 text-gray-500">
               <p className="text-xl">No destinations found matching your filters.</p>
               <button onClick={() => {setFilterRegion('All'); setFilterStyle('All')}} className="mt-4 text-brand-blue underline">Reset Filters</button>
             </div>
          )}
        </div>
      </Section>
    </Layout>
  );
};

export default Destinations;