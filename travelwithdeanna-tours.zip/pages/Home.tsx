import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight, Star } from 'lucide-react';
import { Layout } from '../components/Layout';
import { Button, Section, SectionHeader, FadeIn, ScaleOnHover } from '../components/UIComponents';
import { DESTINATIONS, AWARDS, REVIEWS } from '../constants';

const Home = () => {
  const popularDestinations = DESTINATIONS.slice(0, 6);

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden bg-gradient-to-br from-brand-navy via-brand-ocean to-brand-gold/30">
        <div className="absolute inset-0 bg-[url('https://picsum.photos/1920/1080?random=hero')] bg-cover bg-center opacity-20 mix-blend-overlay"></div>
        
        <div className="max-w-7xl mx-auto px-6 w-full z-10 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="text-white space-y-6"
          >
            <span className="bg-white/10 text-brand-gold px-4 py-1.5 rounded-full text-sm font-semibold border border-white/10 inline-block backdrop-blur-sm">
              Premium Travel Agency
            </span>
            <h1 className="text-4xl md:text-6xl font-heading font-bold leading-tight">
              Discover the World with <span className="text-brand-gold">Travelwithdeanna</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-200 max-w-lg">
              Premium, safe, and seamless travel experiences — trusted by thousands of Malaysians.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              <Button to="/contact" variant="secondary" className="font-bold">
                WhatsApp Us
              </Button>
              <Button to="/destinations" variant="outline" className="!text-white border-white hover:bg-white hover:!text-brand-navy">
                View Packages
              </Button>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="hidden md:block relative"
          >
             <div className="relative w-96 h-96 mx-auto">
                <div className="absolute inset-0 bg-brand-gold rounded-full opacity-20 animate-pulse blur-3xl"></div>
                <img 
                  src="https://picsum.photos/600/600?random=logo" 
                  alt="Travel Experience" 
                  className="rounded-full border-8 border-white/10 shadow-2xl w-full h-full object-cover relative z-10"
                />
             </div>
          </motion.div>
        </div>
      </section>

      {/* USP Section */}
      <Section className="bg-brand-grey/30">
        <FadeIn>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: "Licensed & Trusted", desc: "MOTAC Licensed (L/N/12327). Trusted by public figures." },
              { title: "Expert Support", desc: "Pre-trip guidance and on-trip support for peace of mind." },
              { title: "Maximum Flexibility", desc: "Private tours and open-date packages available." }
            ].map((usp, idx) => (
              <div key={idx} className="bg-white p-8 rounded-2xl shadow-soft flex flex-col items-center text-center hover:shadow-hover transition-shadow">
                <div className="w-12 h-12 bg-brand-gold/10 text-brand-gold rounded-full flex items-center justify-center mb-4">
                  <CheckCircle size={24} />
                </div>
                <h3 className="text-xl font-heading font-bold mb-2 text-brand-navy">{usp.title}</h3>
                <p className="text-gray-500 text-sm">{usp.desc}</p>
              </div>
            ))}
          </div>
        </FadeIn>
      </Section>

      {/* Popular Destinations */}
      <Section>
        <SectionHeader title="Popular Destinations" subtitle="Curated experiences for the modern Malaysian traveler." center />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {popularDestinations.map((dest, idx) => (
            <FadeIn key={dest.id} delay={idx * 0.1}>
              <ScaleOnHover>
                <div className="bg-white rounded-2xl overflow-hidden shadow-soft h-full flex flex-col group">
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src={dest.image} 
                      alt={dest.title} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    {/* Duration badge removed */}
                  </div>
                  <div className="p-6 flex flex-col flex-grow">
                    <h3 className="text-2xl font-heading font-bold text-brand-navy mb-2">{dest.title}</h3>
                    <p className="text-gray-500 text-sm mb-6 flex-grow line-clamp-3">{dest.description}</p>
                    <Button to={`/package/${dest.id}`} variant="outline" fullWidth className="group-hover:bg-brand-blue group-hover:text-white group-hover:border-brand-blue">
                      View Package
                    </Button>
                  </div>
                </div>
              </ScaleOnHover>
            </FadeIn>
          ))}
        </div>
      </Section>

      {/* Company Story Short */}
      <Section className="bg-brand-navy text-white rounded-3xl my-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-brand-ocean/20 rounded-l-full blur-3xl"></div>
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <FadeIn>
            <h2 className="text-3xl md:text-5xl font-heading font-bold mb-6">About Travelwithdeanna</h2>
            <p className="text-gray-300 text-lg mb-4 leading-relaxed">
              Founded in 2020 in Penang, we began with a simple goal: to make travel easier, safer, and more enjoyable for Malaysians.
            </p>
            <p className="text-gray-300 text-lg mb-8 leading-relaxed">
              We specialise in custom tours and group tours across Europe, the Middle East, Balkans, Asia — and soon, Africa.
            </p>
            <Button to="/about" variant="secondary">Read Full Story</Button>
          </FadeIn>
          
          <div className="grid grid-cols-1 gap-4">
             {AWARDS.map((award, idx) => (
               <FadeIn key={award.id} delay={0.2 + (idx * 0.1)} className="bg-white/10 backdrop-blur-md p-4 rounded-xl flex items-center gap-4 border border-white/10">
                 <div className="p-3 bg-brand-gold rounded-full text-white">
                    <award.icon size={20} />
                 </div>
                 <div>
                   <h4 className="font-bold text-lg">{award.title}</h4>
                   <p className="text-sm text-gray-400">{award.year}</p>
                 </div>
               </FadeIn>
             ))}
          </div>
        </div>
      </Section>

      {/* Testimonials */}
      <Section>
        <SectionHeader title="What Travelers Say" center />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {REVIEWS.map((review, idx) => (
            <FadeIn key={review.id} delay={idx * 0.1}>
              <div className="bg-white p-8 rounded-2xl shadow-soft border-t-4 border-brand-gold h-full">
                <div className="flex gap-1 text-brand-gold mb-4">
                  {[...Array(5)].map((_, i) => <Star key={i} size={16} fill="currentColor" />)}
                </div>
                <p className="text-gray-600 italic mb-6">"{review.text}"</p>
                <div className="flex items-center gap-4">
                  <img src={review.avatar} alt={review.name} className="w-12 h-12 rounded-full object-cover" />
                  <div>
                    <h5 className="font-bold text-brand-navy">{review.name}</h5>
                    <p className="text-xs text-gray-500">{review.role}</p>
                  </div>
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </Section>

      {/* CTA */}
      <Section className="pb-24">
        <FadeIn>
          <div className="bg-gradient-to-r from-brand-blue to-brand-ocean rounded-3xl p-12 text-center text-white relative overflow-hidden">
             <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
             <div className="relative z-10 max-w-2xl mx-auto">
               <h2 className="text-3xl md:text-5xl font-heading font-bold mb-6">Ready for your next adventure?</h2>
               <p className="text-lg text-blue-100 mb-8">Chat with our travel specialist to customize your dream itinerary today.</p>
               <Button to="/contact" variant="secondary" className="text-lg px-10 py-4 shadow-xl">
                 WhatsApp HQ <ArrowRight className="ml-2" size={20} />
               </Button>
             </div>
          </div>
        </FadeIn>
      </Section>

    </Layout>
  );
};

export default Home;