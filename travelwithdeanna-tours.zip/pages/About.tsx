import React from 'react';
import { Layout } from '../components/Layout';
import { Section, SectionHeader, FadeIn } from '../components/UIComponents';
import { Heart, Shield, MessageCircle, Smile } from 'lucide-react';
import { AWARDS } from '../constants';

const About = () => {
  return (
    <Layout>
      <div className="bg-brand-navy text-white pt-32 pb-20">
        <Section className="!py-0 text-center">
          <h1 className="text-4xl md:text-6xl font-heading font-bold mb-6">Our Story</h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Making global travel simple, safe, and accessible for Malaysians.
          </p>
        </Section>
      </div>

      <Section>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
           <FadeIn>
             <img 
               src="https://picsum.photos/800/800?random=team" 
               alt="Deanna and Team" 
               className="rounded-3xl shadow-2xl rotate-2 hover:rotate-0 transition-transform duration-500"
             />
           </FadeIn>
           <FadeIn delay={0.2} className="space-y-6">
             <h2 className="text-3xl font-heading font-bold text-brand-navy">A Passion for Exploration</h2>
             <p className="text-gray-600 leading-relaxed">
               Travelwithdeanna Tours is a Malaysian tour operator based in Penang, founded in 2020 by Deanna Rahman. What started as a personal passion for exploring hidden gems turned into a mission to help others see the world with confidence.
             </p>
             <p className="text-gray-600 leading-relaxed">
               Today, we offer custom and group tours across Europe, the Middle East, Asia, the Balkans — and soon, expanding to Africa. We pride ourselves on being "human-first," treating every client like a travel companion rather than just a customer.
             </p>
           </FadeIn>
        </div>
      </Section>

      <Section className="bg-brand-grey/20">
        <SectionHeader title="Our Values" center subtitle="The core principles that guide every trip we plan." />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { icon: Shield, title: "Trust & Safety", desc: "Licensed, insured, and vetted partners only." },
            { icon: Heart, title: "Comfort", desc: "Hotels and transport chosen for maximum comfort." },
            { icon: MessageCircle, title: "Communication", desc: "Clear, honest, and responsive updates." },
            { icon: Smile, title: "Hospitality", desc: "Warm Malaysian service, wherever you go." },
          ].map((val, idx) => (
            <FadeIn key={idx} delay={idx * 0.1}>
              <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow text-center h-full">
                <div className="w-14 h-14 bg-brand-gold/10 text-brand-gold rounded-full flex items-center justify-center mx-auto mb-4">
                  <val.icon size={28} />
                </div>
                <h3 className="font-bold text-brand-navy text-lg mb-2">{val.title}</h3>
                <p className="text-gray-500 text-sm">{val.desc}</p>
              </div>
            </FadeIn>
          ))}
        </div>
      </Section>

      <Section>
        <SectionHeader title="Our Achievements" center />
        <div className="flex flex-wrap justify-center gap-8">
          {AWARDS.map((award, idx) => (
            <FadeIn key={idx} delay={idx * 0.1} className="flex items-center gap-4 bg-brand-navy text-white px-8 py-6 rounded-2xl shadow-lg">
              <award.icon className="text-brand-gold" size={32} />
              <div className="text-left">
                <p className="font-bold text-xl">{award.title}</p>
                <p className="text-brand-gray text-sm opacity-80">{award.year}</p>
              </div>
            </FadeIn>
          ))}
        </div>
      </Section>
    </Layout>
  );
};

export default About;