import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';
import { Link } from 'react-router-dom';

// --- Animations ---
export const FadeIn = ({ children, delay = 0, className = "" }: { children: React.ReactNode, delay?: number, className?: string }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-50px" }}
    transition={{ duration: 0.6, delay, ease: "easeOut" }}
    className={className}
  >
    {children}
  </motion.div>
);

export const ScaleOnHover = ({ children, className = "" }: { children: React.ReactNode, className?: string }) => (
  <motion.div
    whileHover={{ scale: 1.03 }}
    transition={{ type: "spring", stiffness: 300 }}
    className={className}
  >
    {children}
  </motion.div>
);

// --- Buttons ---
interface ButtonProps extends Omit<HTMLMotionProps<"button">, "children"> {
  variant?: 'primary' | 'secondary' | 'outline';
  fullWidth?: boolean;
  to?: string; // If provided, renders as Link
  children: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  fullWidth = false, 
  className = "", 
  to,
  ...props 
}) => {
  const baseStyles = "inline-flex items-center justify-center rounded-xl font-heading font-semibold transition-all duration-300 px-6 py-3 text-sm md:text-base";
  
  const variants = {
    primary: "bg-brand-blue text-white shadow-lg shadow-brand-blue/30 hover:shadow-brand-blue/50 hover:bg-blue-700",
    secondary: "bg-brand-gold text-white shadow-lg shadow-brand-gold/30 hover:shadow-brand-gold/50 hover:brightness-110",
    outline: "border-2 border-brand-navy text-brand-navy hover:bg-brand-navy hover:text-white",
  };

  const widthClass = fullWidth ? "w-full" : "";

  const content = (
    <span className="flex items-center gap-2">
      {children}
    </span>
  );

  if (to) {
    return (
      <Link to={to} className={`${baseStyles} ${variants[variant]} ${widthClass} ${className}`}>
        {content}
      </Link>
    );
  }

  return (
    <motion.button 
      whileTap={{ scale: 0.98 }}
      className={`${baseStyles} ${variants[variant]} ${widthClass} ${className}`}
      {...props}
    >
      {content}
    </motion.button>
  );
};

// --- Section Wrapper ---
export const Section: React.FC<{ children: React.ReactNode, className?: string, id?: string }> = ({ children, className = "", id }) => (
  <section id={id} className={`py-16 md:py-24 px-6 md:px-12 max-w-7xl mx-auto ${className}`}>
    {children}
  </section>
);

// --- Section Header ---
export const SectionHeader: React.FC<{ title: string, subtitle?: string, center?: boolean }> = ({ title, subtitle, center = false }) => (
  <div className={`mb-12 ${center ? 'text-center mx-auto max-w-3xl' : ''}`}>
    <h2 className="text-3xl md:text-4xl font-heading font-bold text-brand-navy mb-4">
      {title}
    </h2>
    {subtitle && <p className="text-gray-600 text-lg leading-relaxed">{subtitle}</p>}
    <div className={`h-1.5 w-24 bg-brand-gold rounded-full mt-4 ${center ? 'mx-auto' : ''}`} />
  </div>
);