import React, { useState } from 'react';
import { Layout } from '../components/Layout';
import { Button, Section, FadeIn } from '../components/UIComponents';
import { Phone, Mail, MapPin } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    destination: '',
    date: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you! We will contact you on WhatsApp shortly.');
    setFormData({ name: '', destination: '', date: '', message: '' });
  };

  return (
    <Layout>
      <div className="bg-brand-navy text-white pt-32 pb-20">
        <Section className="!py-0 text-center">
          <h1 className="text-4xl md:text-6xl font-heading font-bold mb-4">Get In Touch</h1>
          <p className="text-xl text-gray-300">We’re here to help you plan your next adventure.</p>
        </Section>
      </div>

      <Section>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          
          {/* Contact Info */}
          <FadeIn className="space-y-8">
             <div className="bg-brand-gold/10 p-8 rounded-2xl border border-brand-gold/20">
               <h3 className="text-2xl font-heading font-bold text-brand-navy mb-6">Contact Channels</h3>
               <div className="space-y-6">
                 <div className="flex items-center gap-4">
                   <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-brand-navy shadow-sm">
                     <Phone size={24} />
                   </div>
                   <div>
                     <p className="text-sm text-gray-500 font-bold uppercase">WhatsApp HQ</p>
                     <p className="text-lg font-medium text-brand-navy">017-368 0948</p>
                   </div>
                 </div>
                 
                 <div className="flex items-center gap-4">
                   <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-brand-navy shadow-sm">
                     <Mail size={24} />
                   </div>
                   <div>
                     <p className="text-sm text-gray-500 font-bold uppercase">Email</p>
                     <p className="text-lg font-medium text-brand-navy">hello@travelwithdeanna.com</p>
                   </div>
                 </div>

                 <div className="flex items-center gap-4">
                   <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-brand-navy shadow-sm">
                     <MapPin size={24} />
                   </div>
                   <div>
                     <p className="text-sm text-gray-500 font-bold uppercase">Office</p>
                     <p className="text-lg font-medium text-brand-navy">Penang, Malaysia</p>
                   </div>
                 </div>
               </div>
             </div>
             
             <div className="bg-brand-navy p-8 rounded-2xl text-white">
               <h3 className="text-xl font-bold mb-2">Office Hours</h3>
               <p className="text-gray-300">Mon - Fri: 9:00 AM - 6:00 PM</p>
               <p className="text-gray-300">Sat: 10:00 AM - 2:00 PM</p>
               <p className="text-gray-300">Sun: Closed</p>
             </div>
          </FadeIn>

          {/* Form */}
          <FadeIn delay={0.2}>
            <form onSubmit={handleSubmit} className="bg-white p-8 md:p-10 rounded-2xl shadow-soft border border-gray-100">
              <h3 className="text-2xl font-heading font-bold text-brand-navy mb-6">Send an Inquiry</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                  <input 
                    required
                    type="text" 
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/20 outline-none transition-all"
                    placeholder="Your Name"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Destination</label>
                    <input 
                      type="text" 
                      name="destination"
                      value={formData.destination}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/20 outline-none transition-all"
                      placeholder="e.g. Spain"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Travel Date</label>
                    <input 
                      type="date" 
                      name="date"
                      value={formData.date}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/20 outline-none transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                  <textarea 
                    rows={4}
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-brand-gold focus:ring-2 focus:ring-brand-gold/20 outline-none transition-all"
                    placeholder="Tell us about your plans (pax, preferences, etc.)"
                  ></textarea>
                </div>

                <Button type="submit" fullWidth className="mt-4">
                  Send Message
                </Button>
                
                <p className="text-xs text-center text-gray-400 mt-4">
                  By clicking send, you agree to our privacy policy.
                </p>
              </div>
            </form>
          </FadeIn>

        </div>
      </Section>
    </Layout>
  );
};

export default Contact;