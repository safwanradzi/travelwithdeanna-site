import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { Button, Section, FadeIn } from '../components/UIComponents';
import { PACKAGES } from '../constants';
import { ArrowRight } from 'lucide-react';

const PackageDetails = () => {
  const { id } = useParams<{ id: string }>();
  // Default fallback if ID not found
  const pkg = (id && PACKAGES[id]) ? PACKAGES[id] : PACKAGES['spain'];

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  return (
    <Layout>
      {/* 1. Hero Title Section */}
      <div className="relative h-[60vh] w-full flex items-center justify-center">
        <img 
          src={pkg.image} 
          alt={pkg.title} 
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-brand-navy/60 backdrop-blur-sm"></div>
        
        <div className="relative z-10 text-center px-6 max-w-4xl mx-auto mt-16">
          <FadeIn>
             <div className="flex justify-center gap-3 mb-6">
                <span className="bg-brand-gold text-white px-5 py-1.5 rounded-full text-sm font-bold shadow-lg uppercase tracking-wide">
                  {pkg.region}
                </span>
                <span className="bg-white/10 text-white px-5 py-1.5 rounded-full text-sm font-bold border border-white/20 uppercase tracking-wide">
                  {pkg.style}
                </span>
             </div>
             <h1 className="text-4xl md:text-6xl font-heading font-bold text-white mb-6 leading-tight drop-shadow-lg">
               {pkg.title}
             </h1>
          </FadeIn>
        </div>
      </div>

      {/* 2. Description Section */}
      <Section className="bg-white">
        <FadeIn>
          <div className="max-w-3xl mx-auto text-center">
             <div className="h-1.5 w-24 bg-brand-gold rounded-full mx-auto mb-8"></div>
             <p className="text-xl md:text-2xl text-gray-700 font-light leading-relaxed">
               {pkg.description}
             </p>
          </div>
        </FadeIn>
      </Section>

      {/* 3. Image Gallery Section */}
      <Section className="bg-brand-grey/20">
        <div className="max-w-6xl mx-auto">
          <FadeIn>
             <h3 className="text-2xl font-heading font-bold text-brand-navy mb-8 text-center">Gallery</h3>
          </FadeIn>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {pkg.gallery.map((img, idx) => (
              <FadeIn key={idx} delay={idx * 0.1}>
                <div className="aspect-[4/3] overflow-hidden rounded-2xl shadow-soft group relative">
                  <img 
                    src={img} 
                    alt={`${pkg.title} ${idx + 1}`} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-brand-navy/0 group-hover:bg-brand-navy/10 transition-colors duration-500"></div>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </Section>

      {/* 4. Final CTA Section */}
      <Section className="pb-24">
        <FadeIn>
          <div className="bg-gradient-to-r from-brand-navy to-brand-ocean rounded-3xl p-12 text-center text-white relative overflow-hidden shadow-2xl">
             <div className="absolute top-0 right-0 w-96 h-96 bg-brand-gold/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3"></div>
             
             <div className="relative z-10 max-w-2xl mx-auto">
               <h2 className="text-3xl md:text-4xl font-heading font-bold mb-6">Interested in this trip?</h2>
               <p className="text-lg text-blue-100 mb-10 font-light">
                 Our travel specialists are ready to help you plan your perfect {pkg.title} experience.
               </p>
               <Button to="/contact" variant="secondary" className="text-lg px-10 py-5 shadow-xl hover:shadow-2xl hover:-translate-y-1">
                 Chat with Our Travel Advisor <ArrowRight className="ml-2" size={20} />
               </Button>
             </div>
          </div>
        </FadeIn>
      </Section>
    </Layout>
  );
};

export default PackageDetails;